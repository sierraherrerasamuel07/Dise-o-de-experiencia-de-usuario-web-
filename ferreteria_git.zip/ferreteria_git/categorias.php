<?php
$categorias = [
    "Herramientas",
    "Pinturas",
    "Material de construcción",
    "Electricidad",
    "Plomería",
    "Tornillería",
    "Otros"
];