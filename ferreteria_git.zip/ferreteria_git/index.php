<?php
include "conexion.php";

$buscar  = trim($_GET["buscar"] ?? "");
$filtro  = $_GET["categoria"] ?? "";
$mensaje = $_GET["mensaje"] ?? "";

// Números de las tarjetas de resumen (de todo el inventario)
$resumen = $conexion->query(
    "SELECT COUNT(*) AS total,
            COALESCE(SUM(precio * cantidad), 0) AS valor,
            COALESCE(SUM(cantidad = 0), 0) AS agotados,
            COALESCE(SUM(cantidad BETWEEN 1 AND 5), 0) AS pocas
     FROM productos"
)->fetch_assoc();

// Categorías que existen para el menú de filtro
$cats = $conexion->query("SELECT DISTINCT categoria FROM productos ORDER BY categoria");

// Búsqueda y filtro
$sql = "SELECT * FROM productos WHERE 1=1";
$tipos = "";
$params = [];

if ($buscar !== "") {
    $sql .= " AND (nombre LIKE ? OR categoria LIKE ?)";
    $like = "%" . $buscar . "%";
    $tipos .= "ss";
    $params[] = $like;
    $params[] = $like;
}
if ($filtro !== "") {
    $sql .= " AND categoria = ?";
    $tipos .= "s";
    $params[] = $filtro;
}
$sql .= " ORDER BY id";

$stmt = $conexion->prepare($sql);
if ($tipos !== "") {
    $stmt->bind_param($tipos, ...$params);
}
$stmt->execute();
$resultado = $stmt->get_result();
$total = $resultado->num_rows;
$hayFiltros = ($buscar !== "" || $filtro !== "");
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Mi Ferretería - Inventario</title>
  <link rel="stylesheet" href="estilos.css">
</head>
<body>
  <header class="barra">
    <div class="contenido">
      <a class="logo" href="index.php">🔧 Mi <span>Ferretería</span></a>
    </div>
  </header>

  <main class="contenedor">

    <div class="resumen">
      <div class="dato">
        <div class="numero"><?= $resumen["total"] ?></div>
        <div class="texto">Productos registrados</div>
      </div>
      <div class="dato">
        <div class="numero">$<?= number_format($resumen["valor"], 0, ",", ".") ?></div>
        <div class="texto">Valor del inventario</div>
      </div>
      <div class="dato dato-aviso">
        <div class="numero"><?= $resumen["pocas"] ?></div>
        <div class="texto">Con pocas unidades</div>
      </div>
      <div class="dato dato-alerta">
        <div class="numero"><?= $resumen["agotados"] ?></div>
        <div class="texto">Agotados</div>
      </div>
    </div>

    <div class="tarjeta">
      <div class="encabezado">
        <div>
          <h1>Inventario de productos</h1>
          <p class="subtitulo">Mostrando <?= $total ?> de <?= $resumen["total"] ?> productos</p>
        </div>
        <a class="boton boton-principal" href="agregar.php">+ Agregar producto</a>
      </div>

      <?php if ($mensaje === "agregado") { ?>
        <div class="mensaje mensaje-ok">✔ Producto agregado correctamente.</div>
      <?php } elseif ($mensaje === "editado") { ?>
        <div class="mensaje mensaje-ok">✔ Producto actualizado correctamente.</div>
      <?php } elseif ($mensaje === "eliminado") { ?>
        <div class="mensaje mensaje-ok">✔ Producto eliminado correctamente.</div>
      <?php } ?>

      <form method="get" action="index.php" class="filtros">
        <input type="search" name="buscar" placeholder="Buscar por nombre o categoría..."
               value="<?= htmlspecialchars($buscar) ?>">

        <select name="categoria">
          <option value="">Todas las categorías</option>
          <?php while ($c = $cats->fetch_assoc()) { ?>
            <option value="<?= htmlspecialchars($c["categoria"]) ?>"
              <?= $filtro === $c["categoria"] ? "selected" : "" ?>>
              <?= htmlspecialchars($c["categoria"]) ?>
            </option>
          <?php } ?>
        </select>

        <button type="submit" class="boton boton-principal">Buscar</button>
        <?php if ($hayFiltros) { ?>
          <a href="index.php" class="boton boton-secundario">Limpiar</a>
        <?php } ?>
      </form>

      <?php if ($total === 0) { ?>
        <p class="vacio">
          <?= $hayFiltros
              ? "No se encontraron productos con esa búsqueda."
              : "Aún no hay productos. ¡Agrega el primero!" ?>
        </p>
      <?php } else { ?>
      <div class="tabla-envoltura">
        <table>
          <tr>
            <th>N°</th>
            <th>Nombre</th>
            <th>Categoría</th>
            <th>Precio</th>
            <th>Stock</th>
            <th>Acciones</th>
          </tr>
          <?php
          $n = 0;
          while ($fila = $resultado->fetch_assoc()) {
            $n++;
            $cant = (int) $fila["cantidad"];
            if ($cant === 0) {
              $clase = "etiqueta-agotado";
              $texto = "Agotado";
            } elseif ($cant <= 5) {
              $clase = "etiqueta-poco";
              $texto = $cant . " · Pocas unidades";
            } else {
              $clase = "etiqueta-ok";
              $texto = $cant . " disponibles";
            }
          ?>
          <tr>
            <td><?= $n ?></td>
            <td><strong><?= htmlspecialchars($fila["nombre"]) ?></strong></td>
            <td><?= htmlspecialchars($fila["categoria"]) ?></td>
            <td>$<?= number_format($fila["precio"], 0, ",", ".") ?></td>
            <td><span class="etiqueta <?= $clase ?>"><?= $texto ?></span></td>
            <td>
              <div class="acciones">
                <a class="boton boton-secundario boton-chico" href="editar.php?id=<?= $fila["id"] ?>">Editar</a>
                <form method="post" action="eliminar.php"
                      onsubmit="return confirm('¿Seguro que quieres eliminar este producto?');">
                  <input type="hidden" name="id" value="<?= $fila["id"] ?>">
                  <button type="submit" class="boton boton-peligro boton-chico">Eliminar</button>
                </form>
              </div>
            </td>
          </tr>
          <?php } ?>
        </table>
      </div>
      <?php } ?>
    </div>

    <p class="pie">Sistema de inventario · Taller de Diseño UX</p>
  </main>
</body>
</html>