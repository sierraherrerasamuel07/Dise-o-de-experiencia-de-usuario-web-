<?php
include "conexion.php";
include "categorias.php";

$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $id        = (int) $_POST["id"];
    $nombre    = trim($_POST["nombre"]);
    $categoria = trim($_POST["categoria"]);
    $precio    = $_POST["precio"];
    $cantidad  = $_POST["cantidad"];

    $producto = [
        "id" => $id,
        "nombre" => $nombre,
        "categoria" => $categoria,
        "precio" => $precio,
        "cantidad" => $cantidad
    ];

    if ($nombre === "" || $categoria === "" || $precio === "" || $cantidad === "") {
        $error = "Por favor completa todos los campos.";
    } else {
        $stmt = $conexion->prepare(
            "UPDATE productos SET nombre = ?, categoria = ?, precio = ?, cantidad = ? WHERE id = ?"
        );
        $stmt->bind_param("ssdii", $nombre, $categoria, $precio, $cantidad, $id);
        $stmt->execute();

        header("Location: index.php?mensaje=editado");
        exit;
    }
} else {
    $id = (int) ($_GET["id"] ?? 0);

    $stmt = $conexion->prepare("SELECT * FROM productos WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $producto = $stmt->get_result()->fetch_assoc();

    if (!$producto) {
        header("Location: index.php");
        exit;
    }
}

// Lista de categorías: si el producto tiene una que no está en la lista, se agrega para no perderla
$lista = $categorias;
if (!in_array($producto["categoria"], $lista)) {
    $lista[] = $producto["categoria"];
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Editar producto</title>
  <link rel="stylesheet" href="estilos.css">
</head>
<body>
  <header class="barra">
    <div class="contenido">
      <a class="logo" href="index.php">🔧 Mi <span>Ferretería</span></a>
    </div>
  </header>

  <main class="contenedor">
    <div class="tarjeta">
      <div class="encabezado">
        <div>
          <h1>Editar producto</h1>
          <p class="subtitulo">Cambia los datos que necesites y guarda.</p>
        </div>
      </div>

      <?php if ($error !== "") { ?>
        <div class="mensaje mensaje-error">⚠ <?= $error ?></div>
      <?php } ?>

      <form method="post" class="formulario">
        <input type="hidden" name="id" value="<?= (int) $producto["id"] ?>">

        <div class="campo">
          <label for="nombre">Nombre del producto</label>
          <input type="text" id="nombre" name="nombre" maxlength="100" required
                 value="<?= htmlspecialchars($producto["nombre"]) ?>">
        </div>

        <div class="campo">
          <label for="categoria">Categoría</label>
          <select id="categoria" name="categoria" required>
            <?php foreach ($lista as $cat) { ?>
              <option value="<?= htmlspecialchars($cat) ?>"
                <?= $producto["categoria"] === $cat ? "selected" : "" ?>>
                <?= htmlspecialchars($cat) ?>
              </option>
            <?php } ?>
          </select>
        </div>

        <div class="campo">
          <label for="precio">Precio (en pesos)</label>
          <input type="number" id="precio" name="precio" min="0" step="1" required
                 value="<?= (int) $producto["precio"] ?>">
          <p class="ayuda">Escribe solo números, sin puntos ni comas.</p>
        </div>

        <div class="campo">
          <label for="cantidad">Cantidad disponible</label>
          <input type="number" id="cantidad" name="cantidad" min="0" step="1" required
                 value="<?= (int) $producto["cantidad"] ?>">
        </div>

        <div class="botones">
          <button type="submit" class="boton boton-principal">Guardar cambios</button>
          <a href="index.php" class="boton boton-secundario">Cancelar</a>
        </div>
      </form>
    </div>
  </main>
</body>
</html>