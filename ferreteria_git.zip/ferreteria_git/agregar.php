<?php
include "conexion.php";
include "categorias.php";

$error = "";
$nombre = $categoria = $precio = $cantidad = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nombre    = trim($_POST["nombre"]);
    $categoria = trim($_POST["categoria"]);
    $precio    = $_POST["precio"];
    $cantidad  = $_POST["cantidad"];

    if ($nombre === "" || $categoria === "" || $precio === "" || $cantidad === "") {
        $error = "Por favor completa todos los campos.";
    } else {
        $stmt = $conexion->prepare(
            "INSERT INTO productos (nombre, categoria, precio, cantidad) VALUES (?, ?, ?, ?)"
        );
        $stmt->bind_param("ssdi", $nombre, $categoria, $precio, $cantidad);
        $stmt->execute();

        header("Location: index.php?mensaje=agregado");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Agregar producto</title>
  <link rel="stylesheet" href="estilos.css">
</head>
<body>
  <header class="barra">
    <div class="contenido">
      <a class="logo" href="index.php">🔧 Mi <span>Ferretería</span></a>
    </div>
  </header>

  <main class="contenedor">
    <div class="tarjeta">
      <div class="encabezado">
        <div>
          <h1>Agregar producto</h1>
          <p class="subtitulo">Completa los datos del nuevo producto.</p>
        </div>
      </div>

      <?php if ($error !== "") { ?>
        <div class="mensaje mensaje-error">⚠ <?= $error ?></div>
      <?php } ?>

      <form method="post" class="formulario">
        <div class="campo">
          <label for="nombre">Nombre del producto</label>
          <input type="text" id="nombre" name="nombre" placeholder="Ej: Taladro"
                 maxlength="100" required value="<?= htmlspecialchars($nombre) ?>">
        </div>

        <div class="campo">
          <label for="categoria">Categoría</label>
          <select id="categoria" name="categoria" required>
            <option value="">Selecciona una categoría</option>
            <?php foreach ($categorias as $cat) { ?>
              <option value="<?= htmlspecialchars($cat) ?>"
                <?= $categoria === $cat ? "selected" : "" ?>>
                <?= htmlspecialchars($cat) ?>
              </option>
            <?php } ?>
          </select>
        </div>

        <div class="campo">
          <label for="precio">Precio (en pesos)</label>
          <input type="number" id="precio" name="precio" placeholder="Ej: 45000"
                 min="0" step="1" required value="<?= htmlspecialchars($precio) ?>">
          <p class="ayuda">Escribe solo números, sin puntos ni comas.</p>
        </div>

        <div class="campo">
          <label for="cantidad">Cantidad disponible</label>
          <input type="number" id="cantidad" name="cantidad" placeholder="Ej: 5"
                 min="0" step="1" required value="<?= htmlspecialchars($cantidad) ?>">
        </div>

        <div class="botones">
          <button type="submit" class="boton boton-principal">Guardar producto</button>
          <a href="index.php" class="boton boton-secundario">Cancelar</a>
        </div>
      </form>
    </div>
  </main>
</body>
</html>